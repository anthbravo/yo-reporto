export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyAGIUc0zZs5qSsjWlIcYqej9h7X2DSilYE",
    authDomain: "yo-reporto-upc.firebaseapp.com",
    databaseURL: "https://yo-reporto-upc.firebaseio.com",
    projectId: "yo-reporto-upc",
    storageBucket: "yo-reporto-upc.appspot.com",
    messagingSenderId: "630074311747"
  }
};
