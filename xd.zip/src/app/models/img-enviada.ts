
export class ImgEnviada {
   
    constructor (private url:string,public fecha:string,private estado:string){}
}
