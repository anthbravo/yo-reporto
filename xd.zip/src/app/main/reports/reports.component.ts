import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'a-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss']
})
export class ReportsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
