import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ImgStorageService } from '../../shared/services/img-storage.service';
import { ImgEnviada } from '../../models/img-enviada'
@Component({
  selector: 'a-camera',
  templateUrl: './camera.component.html',
  styleUrls: ['./camera.component.scss']
})
export class CameraComponent implements OnInit {
  @ViewChild("video")
  public video: ElementRef;

  @ViewChild("canvas")
  public canvas: ElementRef;
  @ViewChild("download")
  public download: ElementRef;
  @ViewChild("logo")
  public logo: ElementRef;

  public captures: Array<any>;

  public constructor(private imgStorage: ImgStorageService) {
    this.captures = [];
  }

  public ngOnInit() {

  }

  public ngAfterViewInit() {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      navigator.mediaDevices.getUserMedia({ audio: true, video: { facingMode: "user" } }).then(stream => {
        this.video.nativeElement.src = window.URL.createObjectURL(stream);
        this.video.nativeElement.play();

      });
    }
  }

  public capture() {
    var context = this.canvas.nativeElement.getContext("2d").drawImage(this.video.nativeElement, 0, 0, 640, 480);
    this.captures.push(this.canvas.nativeElement.toDataURL("image/png"));
    let url = this.canvas.nativeElement.toDataURL("image/png");
    let nuevaImg: ImgEnviada;
    let date = new Date();
    let fecha: string;
    fecha = date.getDate() + "/" + (date.getMonth() + 1) + "/" + date.getFullYear();
    nuevaImg = new ImgEnviada(url, fecha, "pendiente");
    this.imgStorage.insertProduct(nuevaImg);
  }
  public downloads() {
    let nuevaImg: ImgEnviada;
    //let data:string= this.imgStorage.getProduct();
   this.imgStorage.getProduct();
    //this.logo.nativeElement.src=data;
  }

}
